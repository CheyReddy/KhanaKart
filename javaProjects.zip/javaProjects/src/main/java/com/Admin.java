package com;

public class Admin {
	private int adminId;
	private String adminName;
	private String adminPassword;
	private String adminMobileNo;
	private String email;

	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	public String getAdminMobileNo() {
		return adminMobileNo;
	}
	public void setAdminMobileNo(String adminMobileNo) {
		this.adminMobileNo = adminMobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public Admin() {
		super();
	}
	public Admin(int adminId, String adminName, String adminPassword, String adminMobileNo, String email) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminPassword = adminPassword;
		this.adminMobileNo = adminMobileNo;
		this.email = email;
	}
	public Admin(String adminName, String adminPassword, String adminMobileNo, String email) {
		super();
		this.adminName = adminName;
		this.adminPassword = adminPassword;
		this.adminMobileNo = adminMobileNo;
		this.email = email;
	}

	@Override
	public String toString() {
		return adminId + " " + adminName + " " + adminPassword
				+ " " + adminMobileNo + " " + email;
	}



}
