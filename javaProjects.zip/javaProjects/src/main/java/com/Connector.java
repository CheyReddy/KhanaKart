package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Connector {

	static Connection con;
	static Statement stmt;
	static PreparedStatement pstmt;
	static ResultSet res;


	public static Connection connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddelivery","root","root");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return con;

	}

}
