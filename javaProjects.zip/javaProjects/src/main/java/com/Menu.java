package com;

public class Menu {


	private int menuid;
	private int restaurantid;
	private String itemName;
	private String itemDescription;
	private double price;
	private String isAvailable;
	private String imgPath;

	public int getMenuid() {
		return menuid;
	}

	public void setMenuid(int menuid) {
		this.menuid = menuid;
	}

	public int getRestaurantid() {
		return restaurantid;
	}

	public void setRestaurantid(int restaurantid) {
		this.restaurantid = restaurantid;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	public Menu() {
		super();
	}

	public Menu(int menuid,int restaurantid,String itemName,String itemDescription,double price,String isAvailable,String imgPath) {
		super();
		this.menuid = menuid;
		this.restaurantid = restaurantid;
		this.itemName = itemName;
		this.itemDescription=itemDescription;
		this.price = price;
		this.isAvailable=isAvailable;
		this.imgPath=imgPath;

	}

	public Menu(int restaurantid,String itemName,String itemDescription,double price,String isAvailable,String imgPath) {
		super();
		this.restaurantid = restaurantid;
		this.itemName = itemName;
		this.itemDescription=itemDescription;
		this.price = price;
		this.isAvailable=isAvailable;
		this.imgPath=imgPath;
	}


	@Override
	public String toString() {
		return menuid+" "+restaurantid+" "+itemName+" "+itemDescription+" "+price+" "+isAvailable+" "+imgPath;
	}
}
