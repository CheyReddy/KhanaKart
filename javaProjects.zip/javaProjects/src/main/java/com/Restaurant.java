package com;

public class Restaurant {
	private  int restaurantid;
	private  String restaurantName;
	private  String cuisine;
	private  String mobileNo;
	private  String address;
	private  String city;
	private  String isActive;
	private  String ratings;

	public int getRestaurantid() {
		return restaurantid;
	}
	public void setRestaurant_id(int restaurant_id) {
		this.restaurantid = restaurant_id;
	}
	public String getRestaurantName() {
		return restaurantName;
	}
	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}
	public String getCuisine() {
		return cuisine;
	}
	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getRatings() {
		return ratings;
	}
	public void setRatings(String ratings) {
		this.ratings = ratings;
	}

	public Restaurant() {
		super();
	}
	public Restaurant(String restaurantName, String cuisine, String mobileNo, String address, String city,
			String isActive, String ratings) {
		super();
		this.restaurantName = restaurantName;
		this.cuisine = cuisine;
		this.mobileNo = mobileNo;
		this.address = address;
		this.city = city;
		this.isActive = isActive;
		this.ratings = ratings;
	}
	public Restaurant(int restaurantid, String restaurantName, String cuisine, String mobileNo,
			String address, String city, String isActive, String ratings) {
		super();
		this.restaurantid = restaurantid;
		this.restaurantName = restaurantName;
		this.cuisine = cuisine;
		this.mobileNo = mobileNo;
		this.address = address;
		this.city = city;
		this.isActive = isActive;
		this.ratings = ratings;
	}
	@Override
	public String toString() {
		return restaurantid+" "+restaurantName+" "+cuisine+" "+mobileNo+" "+address+" "+
						city+" "+isActive+" "+ratings;
	}

}
