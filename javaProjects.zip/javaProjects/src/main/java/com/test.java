package com;

import java.util.Map;

public class test {
	public static void main(String[] args) {
		Cart c = new Cart();
		Map<Integer,CartItem> items = c.getItems();

		for(int i : items.keySet()) {
			System.out.println(i);
		}
	}
}
