package dao;

import java.util.List;

import com.Admin;

public interface AdminDAO {
	int insertAdminData(Admin admin);
	List<Admin> getAllAdmins();
	Admin getAdminByEmail(String email);
	int deleteAdminById(int id);
	int updateAdminByid(int id, String address);

}
