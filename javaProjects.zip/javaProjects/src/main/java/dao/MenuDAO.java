package dao;

import java.util.List;

import com.Menu;

public interface MenuDAO {
	int insertMenuData(Menu menu);
	List<Menu> getAllMenu();
	Menu getMenuById(int id);
	int deleteMenuByRestaurantId(int id);
	int updateMenuByRestaurantId(int id, String isAvailable, double price);
	int updateMenuByMenuId(int menuid, int qunatity);
	int deleteMenuByMenuId(int menuid);
}
