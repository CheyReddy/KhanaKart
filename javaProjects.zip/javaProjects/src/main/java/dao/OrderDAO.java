package dao;

import com.Order;

public interface OrderDAO {
	int insertOrder(Order order);
	Order fetchOnOrderId(int orderid);
	int updateOrder(int orderid, String status);
}
