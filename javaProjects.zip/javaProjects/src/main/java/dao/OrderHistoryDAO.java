package dao;

import com.OrderHistory;

public interface OrderHistoryDAO {
	OrderHistory fetchOrderOnId(int userid);
	int insertOrderHistory(OrderHistory orderhistory);
	int updateOrderHistory(int orderhistoryid, String status);
}
