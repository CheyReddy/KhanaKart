package dao;

import com.OrderItems;

public interface OrderItemDAO {
	int insertOrder(OrderItems orderitems);
	OrderItems fetchOnOrderId(int orderid);
}
