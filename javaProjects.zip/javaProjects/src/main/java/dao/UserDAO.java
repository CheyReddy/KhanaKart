package dao;

import java.sql.ResultSet;
import java.util.List;

import com.User;

public interface UserDAO {
	int insertUserData(User user);
	List<User> getAllUsers();
	User getUserByEmail(String email);
	int deleteUserById(int id);
	int updateUser(String password, String email);
	ResultSet getUserNameByName(String name);
	ResultSet getUserpasswordByPassword(String password);
	User userValidation(String email, String dob);
}
