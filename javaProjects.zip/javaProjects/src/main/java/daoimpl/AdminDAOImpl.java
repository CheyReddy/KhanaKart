package daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Admin;

import dao.AdminDAO;

public class AdminDAOImpl implements AdminDAO{

	static Connection con;
	static Statement stmt;
	static PreparedStatement pstmt;
	static ResultSet res;
	static int x = -1;

	static final String INSERT_ADMIN_DATA = "insert into admin (adminName,adminPassword,adminMobileNo,email) values(?,?,?,?)";
	static final String DELETE_DATA_BY_ID = "delete from admin where adminid = ?";
	static final String UPDATE_DATA_BY_ID = "update admin set email = ? where adminid = ?";
	static final String FETCH_DATA_BY_EMAIL = "select * from admin where email = ?";
	static final String FETCH_ALL_DATA = "select * from admin";

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddelivery","root","root");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int insertAdminData(Admin admin) {
		try {
			pstmt = con.prepareStatement(INSERT_ADMIN_DATA);
			pstmt.setString(1, admin.getAdminName());
			pstmt.setString(2, admin.getAdminPassword());
			pstmt.setString(3, admin.getAdminMobileNo());
			pstmt.setString(4, admin.getEmail());
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public List<Admin> getAllAdmins() {
		ArrayList<Admin> arr = new ArrayList<>();
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(FETCH_ALL_DATA);

			while(res.next()) {
				arr.add(new Admin(res.getInt(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5)));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	@Override
	public Admin getAdminByEmail(String email) {
		Admin a = null;
		try {
			pstmt = con.prepareStatement(FETCH_DATA_BY_EMAIL);
			pstmt.setString(1, email);
			res = pstmt.executeQuery();

			while(res.next()) {
				a = new Admin(res.getInt("adminId"),res.getString("adminName"),res.getString("adminPassword"),res.getString("adminMobileNo"),res.getString("email"));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return a;
	}

	@Override
	public int deleteAdminById(int id) {
		try {
			pstmt = con.prepareStatement(DELETE_DATA_BY_ID);
			pstmt.setInt(1, id);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public int updateAdminByid(int id, String address) {
		try {
			pstmt = con.prepareStatement(UPDATE_DATA_BY_ID);
			pstmt.setString(1, address);
			pstmt.setInt(2, id);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

}
