package daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Menu;

import dao.MenuDAO;

public class MenuDAOImpl implements MenuDAO{
	static private Connection con;
	static private Statement stmt;
	static private PreparedStatement pstmt;
	static private ResultSet res;
	static int x = -1;

	static final String INSERT_USER_DATA = "insert into menu (restaurantid,itemname,itemdescription,price,isavailable,imgpath) values(?,?,?,?,?,?)";
	static final String DELETE_DATA_BY_RESTAURANTID = "delete from menu where restaurantid = ?";
	static final String UPDATE_DATA_BY_RESTAURANTID = "update menu set isavailable = ?, price=? where restaurantid = ?";
	static final String FETCH_DATA_BY_RESTAURANTID = "select * from menu where menuid = ?";
	static final String FETCH_ALL_DATA = "select * from menu";
	static final String UPDATE_DATA_BY_MENUID = "update menu set quantity = ? where menuid = ?";
	static final String DELETE_DATA_BY_MENUID = "delete from menu where menuid = ?";
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddelivery","root","root");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int insertMenuData(Menu menu) {
		try {
			pstmt = con.prepareStatement(INSERT_USER_DATA);
			pstmt.setInt(1, menu.getRestaurantid());
			pstmt.setString(2, menu.getItemName());
			pstmt.setString(3, menu.getItemDescription());
			pstmt.setDouble(4, menu.getPrice());
			pstmt.setString(5, menu.getIsAvailable());
			pstmt.setString(6, menu.getImgPath());
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public List<Menu> getAllMenu() {
		ArrayList<Menu> arr = new ArrayList();
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(FETCH_ALL_DATA);

			while(res.next()) {
				arr.add(new Menu(res.getInt("menuid"),res.getInt("restaurantid"),res.getString("itemName"),res.getString("itemDescription"),
						res.getDouble("price"),res.getString("isAvailable"),res.getString("imgPath")));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	@Override
	public Menu getMenuById(int id) {
		Menu m = null;
		try {
			pstmt = con.prepareStatement(FETCH_DATA_BY_RESTAURANTID);
			pstmt.setInt(1, id);
			res = pstmt.executeQuery();

			while(res.next()) {
				m = new Menu(res.getInt("restaurantid"),res.getString("itemName"),res.getString("itemDescription"),
						res.getDouble("price"),res.getString("isAvailable"),res.getString("imgPath"));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return m;
	}

	@Override
	public int deleteMenuByRestaurantId(int id) {
		try {
			pstmt = con.prepareStatement(DELETE_DATA_BY_RESTAURANTID);
			pstmt.setInt(1, id);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public int deleteMenuByMenuId(int menuid) {
		try {
			pstmt = con.prepareStatement(DELETE_DATA_BY_MENUID);
			pstmt.setInt(1, menuid);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public int updateMenuByRestaurantId(int id, String isAvailable, double price) {
		try {
			pstmt = con.prepareStatement(UPDATE_DATA_BY_RESTAURANTID);
			pstmt.setString(1, isAvailable);
			pstmt.setDouble(2, price);
			pstmt.setInt(3, id);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public int updateMenuByMenuId(int menuid, int quantity) {
		try {
			pstmt = con.prepareStatement(UPDATE_DATA_BY_MENUID);
			pstmt.setInt(1, quantity);
			pstmt.setInt(2, menuid);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

}
