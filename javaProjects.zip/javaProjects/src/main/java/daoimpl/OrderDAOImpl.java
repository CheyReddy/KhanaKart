package daoimpl;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.Order;

import dao.OrderDAO;

public class OrderDAOImpl implements OrderDAO{

	private static Connection con;
	private static Statement stmt;
	private static PreparedStatement pstmt;
	private static ResultSet res;

	static final String INSERT_ORDER_DATA = "insert into orders (userid,restaurantid,totalamount,orderstatus,payment) values(?,?,?,?,?)";
	static final String UPDATE_DATA_BY_ID = "update orders set status = ? where orderid = ?";
	static final String FETCH_DATA_BY_ID = "select * from orders where orderid = ?";

	static {
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddelivery","root","root");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int insertOrder(Order order) {
		try {
			pstmt = con.prepareStatement(INSERT_ORDER_DATA);
			pstmt.setInt(1, order.getUserId());
			pstmt.setInt(2, order.getRestaurantId());
			pstmt.setInt(3, order.getTotalAmount());
			pstmt.setString(4, order.getStatus());
			pstmt.setString(5, order.getPaymentOption());
			int i = pstmt.executeUpdate();
			return i;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public Order fetchOnOrderId(int orderid) {
		Order o =null;
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(FETCH_DATA_BY_ID);
			while(res.next()) {
				o = new Order(res.getInt(1),res.getInt(2),res.getInt(3),res.getInt(4),
						res.getString(5),res.getString(6));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return o;
	}

	@Override
	public int updateOrder(int orderid, String status) {
		try {
			pstmt = con.prepareStatement(UPDATE_DATA_BY_ID);
			pstmt.setInt(1, orderid);
			pstmt.setString(2, status);
			int i = pstmt.executeUpdate();
			return i;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return 0;
	}

}

