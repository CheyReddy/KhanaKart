package daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.OrderHistory;

import dao.OrderHistoryDAO;

public class OrderHistoryDAOImpl implements OrderHistoryDAO{

	private static Connection con;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet res;

	static final String INSERT_ORDER_DATA = "insert into orderhistory (userid,orderid,total,orderstatus) values(?,?,?,?)";
	static final String UPDATE_DATA_BY_ID = "update orderhistory set status = ? where orderid = ?";
	static final String FETCH_DATA_BY_ID = "select * from orderhistory where orderhistoryid = ?";

	static {
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddelivery","root","root");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public OrderHistory fetchOrderOnId(int userid) {
		OrderHistory oh =null;
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(FETCH_DATA_BY_ID);
			while(res.next()) {
				oh = new OrderHistory(res.getInt(1),res.getInt(2),res.getInt(3),res.getInt(4),
						res.getString(5));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return oh;
	}

	@Override
	public int insertOrderHistory(OrderHistory orderHistory) {
		try {
			pstmt = con.prepareStatement(INSERT_ORDER_DATA);
			pstmt.setInt(1, orderHistory.getUserId());
			pstmt.setInt(2, orderHistory.getOrderId());
			pstmt.setInt(3, orderHistory.getTotal());
			pstmt.setString(4, orderHistory.getStatus());
			int i = pstmt.executeUpdate();
			return i;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int updateOrderHistory(int orderhistoryid, String status) {
		try {
			pstmt = con.prepareStatement(UPDATE_DATA_BY_ID);
			pstmt.setInt(1, orderhistoryid);
			pstmt.setString(2, status);
			int i = pstmt.executeUpdate();
			return i;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return 0;
	}

}
