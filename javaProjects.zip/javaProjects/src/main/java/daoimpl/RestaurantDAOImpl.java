package daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Restaurant;

import dao.RestaurantDAO;

public class RestaurantDAOImpl implements RestaurantDAO{
	static Connection con;
	static Statement stmt;
	static PreparedStatement pstmt;
	static ResultSet res;
	static int x = -1;

	ArrayList<Restaurant> arr;

	static final String INSERT_DATA_INTO_REST= "insert into restaurant (restaurantname,cuisine,mobileno,address,city,isActive,ratings) values(?,?,?,?,?,?,?)";
	static final String FETCH_DATA_BY_ID = "select * from restaurant where restaurantid = ?";
	static final String DELETE_DATA_BY_ID = "delete from restaurant where restaurantid = ?";
	static final String UPDATE_DATA_BY_ID = "update restaurant set isActive = ? where restaurantid = ?";
	static final String FETCH_ALL_DATA = "select * from restaurant";
	static final String FETCH_RESTONAME_BY_ID = "select restaurantname from restaurant where restaurantid = ?";


	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddelivery","root","root");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int insertRestaurant(Restaurant rest) {
		try {
			pstmt = con.prepareStatement(INSERT_DATA_INTO_REST);
			pstmt.setString(1, rest.getRestaurantName());
			pstmt.setString(2, rest.getCuisine());
			pstmt.setString(3, rest.getMobileNo());
			pstmt.setString(4, rest.getAddress());
			pstmt.setString(5, rest.getCity());
			pstmt.setString(6, rest.getIsActive());
			pstmt.setString(7, rest.getRatings());
			x = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public List<Restaurant> getAllRest() {
		arr = new ArrayList();
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(FETCH_ALL_DATA);
			while(res.next()) {
				arr.add(new Restaurant(res.getInt(1),res.getString(2),res.getString(3),res.getString(4),
						res.getString(5),res.getString(6),res.getString(7),res.getString(8)));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	@Override
	public Restaurant getRestById(int id) {
		Restaurant rest = null;
		try {
			pstmt = con.prepareStatement(FETCH_DATA_BY_ID);
			pstmt.setInt(1, id);
			res = pstmt.executeQuery();

			while(res.next()) {
				rest = new Restaurant(res.getInt(1),res.getString(2),res.getString(3),res.getString(4),
						res.getString(5),res.getString(6),res.getString(7),res.getString(8));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return rest;
	}

	@Override
	public int deleteRestById(int id) {
		try {
			pstmt = con.prepareStatement(DELETE_DATA_BY_ID);
			pstmt.setInt(1, id);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public int updateRestById(int id, String isActive) {
		try {
			pstmt = con.prepareStatement(UPDATE_DATA_BY_ID);
			pstmt.setString(1, isActive);
			pstmt.setInt(2, id);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

//	@Override
//	public String getRestoNameById(int id) {
//		Restaurant rest = null;
//		try {
//			pstmt = con.prepareStatement(FETCH_RESTONAME_BY_ID);
//			pstmt.setInt(1, id);
//			res = pstmt.executeQuery();
//			System.out.println(res);
//
//			if(res != null) {
//			while(res.next()) {
//				rest = new Restaurant(res.getInt(1),res.getString(2),res.getString(3),res.getString(4),
//						res.getString(5),res.getString(6),res.getString(7),res.getString(8));
//				}
//			}
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println(rest);
//		return rest.getRestaurantName();
//	}

}
