package daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.User;

import dao.UserDAO;

public class UserDAOImpl implements UserDAO{

	static Connection con;
	static Statement stmt;
	static PreparedStatement pstmt;
	static ResultSet res;
	static int x = -1;

	static final String INSERT_USER_DATA = "insert into users (username,userpassword,email,gender,address,mobileNo,dob) values(?,?,?,?,?,?,?)";
	static final String DELETE_DATA_BY_ID = "delete from users where userid = ?";
	static final String UPDATE_DATA_BY_EMAIL = "update users set userpassword = ? where email = ?";
	static final String FETCH_DATA_BY_EMAIL = "select * from users where email = ?";
	static final String FETCH_ALL_DATA = "select * from users";
	static final String FETCH_NAME_BY_NAME = "select username from users where username = ?";
	static final String FETCH_PASSWORD_BY_PASSWORD = "select userpassword from users where userpassword = ?";
	static final String Reset_Password = "select * from users where email=? and dob=?";

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddelivery","root","root");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int insertUserData(User user) {
		try {
			pstmt = con.prepareStatement(INSERT_USER_DATA);
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getEmail());
			pstmt.setString(4, user.getGender());
			pstmt.setString(5, user.getAddress());
			pstmt.setString(6, user.getMobileNo());
			pstmt.setString(7, user.getDob());
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public List<User> getAllUsers() {
		ArrayList<User> arr = new ArrayList();
		try {
			stmt = con.createStatement();
			res = stmt.executeQuery(FETCH_ALL_DATA);

			while(res.next()) {
				arr.add(new User(res.getInt("userid"),res.getString("username"),res.getString("userpassword"),res.getString("mobileno"),res.getString("email")
						,res.getString("dob"),res.getString("gender"),res.getString("address")));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

	@Override
	public User getUserByEmail(String email) {
		User u=null;
		try {
			pstmt = con.prepareStatement(FETCH_DATA_BY_EMAIL);
			pstmt.setString(1, email);
			res = pstmt.executeQuery();

			while(res.next()) {
				u = new User(res.getString("username"),res.getString("userpassword"),res.getString("mobileno"),res.getString("email")
						,res.getString("dob"),res.getString("gender"),res.getString("address"));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return u;
	}

	@Override
	public int deleteUserById(int id) {
		try {
			pstmt = con.prepareStatement(DELETE_DATA_BY_ID);
			pstmt.setInt(1, id);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public int updateUser(String password, String email) {
		try {
			pstmt = con.prepareStatement(UPDATE_DATA_BY_EMAIL);
			pstmt.setString(1, password);
			pstmt.setString(2, email);
			x = pstmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return x;
	}

	@Override
	public ResultSet getUserNameByName(String name) {
		try {
			pstmt = con.prepareStatement(FETCH_NAME_BY_NAME);
			pstmt.setString(1, name);
			res = pstmt.executeQuery();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public ResultSet getUserpasswordByPassword(String password) {
		try {
			pstmt = con.prepareStatement(FETCH_PASSWORD_BY_PASSWORD);
			pstmt.setString(1, password);
			res = pstmt.executeQuery();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public User userValidation(String email, String dob) {
		User u = null;
		try {
			pstmt = con.prepareStatement(Reset_Password);
			pstmt.setString(1, email);
			pstmt.setString(2, dob);
			res = pstmt.executeQuery();
			if(res.next()) {
				u = new User(res.getString("username"),res.getString("userpassword"),res.getString("mobileno"),res.getString("email")
						,res.getString("dob"),res.getString("gender"),res.getString("address"));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return u;
	}
}