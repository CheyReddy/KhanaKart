package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Connector;
import com.Menu;


@WebServlet("/AdminMenuServlet")
public class AdminMenuServlet extends HttpServlet {
	private HttpSession session;
	private PreparedStatement pstmt;
	private ResultSet res;
	private List<Menu> menuList = new ArrayList();
	String fetchAll = "select * from menu where restaurantid = ?";

	@Override
	public void init() throws ServletException {
		try {
			Connection con = Connector.connect();
			pstmt = con.prepareStatement(fetchAll);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		session = req.getSession();
		try {
			int restaurantid = Integer.parseInt(req.getParameter("restaurantid"));
			pstmt.setInt(1, restaurantid);
			res = pstmt.executeQuery();
			menuList.clear();
			while(res.next()) {
				menuList.add(new Menu(res.getInt("menuid"),res.getInt("restaurantid"),res.getString("itemName"),res.getString("itemDescription"),
						res.getInt("price"),res.getString("isAvailable"),res.getString("imgPath")));
			}

			session.setAttribute("restaurantID", restaurantid);
			session.setAttribute("menuList", menuList);
			resp.sendRedirect("AdminMenu.jsp");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}






