package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Admin;
import com.Connector;

import daoimpl.AdminDAOImpl;


@WebServlet("/adminValidate")
public class AdminServlet extends HttpServlet {

	private HttpSession session;
	private ArrayList<Admin> adminList = new ArrayList<>();
	private Connection con;


	@Override
	public void init() throws ServletException {
		try {
			con = Connector.connect();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String password = req.getParameter("password");
		String email = req.getParameter("email");

		session = req.getSession();
		session.removeAttribute("error");

		AdminDAOImpl aimpl = new AdminDAOImpl();
		Admin a = aimpl.getAdminByEmail(email);
		session = req.getSession();
		session.setAttribute("invalid", "invalid email!");
		if(a!=null) {
			String dbPassword = a.getAdminPassword();
			if(dbPassword.equals(password)) {
				adminList.add(a);

				session.setAttribute("adminList", adminList);
				session.setAttribute("adminname", a.getAdminName());

				resp.sendRedirect("AdminHome.jsp");
			}
			else {
				session.setAttribute("error", "Invalid Password, Try again.!");
				resp.sendRedirect("AdminLogin.jsp");
			}
		}
		else {
			session.setAttribute("error", "Invalid Email.!");
			resp.sendRedirect("AdminLogin.jsp");
		}
	}


}
