package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Cart;
import com.CartItem;
import com.Menu;

import daoimpl.MenuDAOImpl;


@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		Cart cart=(Cart)session.getAttribute("cart");
		if(cart==null) {
			cart=new Cart();
			session.setAttribute("cart", cart);
		}
		String action=req.getParameter("action");
		if("add".equals(action)) {
			addItemsToCart(req,cart);
			session.setAttribute("cart", cart);
			resp.sendRedirect("Menu.jsp");
		}else if("update".equals(action)) {
			updateCartItem(req,cart);
			session.setAttribute("cart", cart);
			resp.sendRedirect("Cart.jsp");
		}else if("delete".equals(action)) {
			removeItemFromCart(req,cart);
			session.setAttribute("cart", cart);
			resp.sendRedirect("Cart.jsp");
		}else if("clear".equals(action)) {
			clearCart(req,cart);
			session.setAttribute("cart", cart);
			resp.sendRedirect("Cart.jsp");
		}
		
	}

	private void addItemsToCart(HttpServletRequest req, Cart cart) {
		int itemId=Integer.parseInt(req.getParameter("itemId"));
		int quantity=Integer.parseInt(req.getParameter("quantity"));
		MenuDAOImpl mimpl=new MenuDAOImpl();
		Menu menu=mimpl.getMenuById(itemId);
		HttpSession session=req.getSession();
		session.setAttribute("restaurantid", menu.getRestaurantid());
		
		if(menu!=null) {
			CartItem item=new CartItem(itemId,menu.getRestaurantid(),
					menu.getItemName(),quantity,menu.getPrice(),
					menu.getPrice()*quantity);
			cart.addItem(item);
		}
			
	}

	private void updateCartItem(HttpServletRequest req, Cart cart) {
		int itemId=Integer.parseInt(req.getParameter("itemId"));
		int quantity=Integer.parseInt(req.getParameter("quantity"));
		
		MenuDAOImpl mimpl=new MenuDAOImpl();
		Menu menu=mimpl.getMenuById(itemId);
		
		if(menu!=null) {
			CartItem item=new CartItem(itemId,menu.getRestaurantid(),
					menu.getItemName(),quantity,menu.getPrice(),
					menu.getPrice()*quantity);
			cart.updateItem(itemId, quantity);
			
		}
		
	}
	private void removeItemFromCart(HttpServletRequest req, Cart cart) {
		int itemId=Integer.parseInt(req.getParameter("itemId"));
		cart.removeItem(itemId);
	}
	private void clearCart(HttpServletRequest req,Cart cart) {
		cart.clear();
	}

}















