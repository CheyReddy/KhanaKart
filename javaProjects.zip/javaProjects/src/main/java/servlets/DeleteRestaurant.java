package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Restaurant;

import daoimpl.RestaurantDAOImpl;


@WebServlet("/DeleteRestaurant")
public class DeleteRestaurant extends HttpServlet {

	private HttpSession session;
	private ArrayList<Restaurant> restaurantList;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		session = req.getSession();
		restaurantList = (ArrayList<Restaurant>) session.getAttribute("restaurantList");

		RestaurantDAOImpl mimpl = new RestaurantDAOImpl();
		int x = mimpl.deleteRestById(Integer.parseInt(req.getParameter("restaurantid")));
		if(x!=0) {
			resp.sendRedirect("FetchRestaurant");
		}
		else {
			resp.sendRedirect("FetchRestaurant");
		}
	}
}
