package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Connector;
import com.Restaurant;

@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {
	String fetchAll = "select * from restaurant";
	private Statement stmt;
	private ResultSet res;
	private HttpSession session;
	private List<Restaurant> restaurantList = new ArrayList();

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		session = req.getSession();
		session.setAttribute("username","not");
		session.setAttribute("error","not");
		try {
			Connection con = Connector.connect();
			stmt=con.createStatement();
			res = stmt.executeQuery(fetchAll);
			restaurantList.clear();
			while(res.next()) {
				restaurantList.add(new Restaurant(res.getInt("restaurantid"),res.getString("restaurantname"), res.getString("cuisine"), res.getString("mobileno"),
						res.getString("address"), res.getString("city"), res.getString("isactive"), res.getString("ratings")));
			}

			session.setAttribute("restaurantList", restaurantList);
			resp.sendRedirect("Home.jsp");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}






















