package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Menu;

import daoimpl.MenuDAOImpl;

@WebServlet("/InsertMenu")
public class InsertMenu extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int restaurantid = Integer.parseInt(req.getParameter("restaurantid"));
		String itemname = req.getParameter("itemname");
		String itemdescription = req.getParameter("itemdescription");
		int price = Integer.parseInt(req.getParameter("price"));
		String itemavailability = req.getParameter("itemavailability");
		String imglink = req.getParameter("imglink");

		MenuDAOImpl mimpl = new MenuDAOImpl();
		Menu m = new Menu(restaurantid,itemname,itemdescription,price,itemavailability,imglink);
		int x = mimpl.insertMenuData(m);
		if(x!=0)
		{
			resp.sendRedirect("FetchMenu");
		}
		else
		{
			resp.sendRedirect("AddItemToMenu.jsp");
		}
	}
}
