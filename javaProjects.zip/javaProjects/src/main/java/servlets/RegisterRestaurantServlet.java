package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Restaurant;

import daoimpl.RestaurantDAOImpl;

@WebServlet("/RegisterRestaurant")
public class RegisterRestaurantServlet extends HttpServlet {

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String restaurantname = req.getParameter("restaurantname");
		String cuisine = req.getParameter("cuisine");
		String mobileNo = req.getParameter("mobileno");
		String activestatus = req.getParameter("activestatus");
		String address = req.getParameter("address");
		String city = req.getParameter("city");
		String rating = req.getParameter("rating");

		RestaurantDAOImpl rimpl = new RestaurantDAOImpl();
		Restaurant r = new Restaurant(restaurantname,cuisine,mobileNo,address,city,activestatus,rating);

		int i = rimpl.insertRestaurant(r);
		if(i==0) {
			resp.sendRedirect("RestaurantNewUser.jsp");
		}
		else {
			resp.sendRedirect("FetchRestaurant");
		}
	}
}
