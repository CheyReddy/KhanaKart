package servlets;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Connector;
import com.User;

import daoimpl.UserDAOImpl;

@WebServlet("/registerUserServlet")
public class RegisterUserServlet extends HttpServlet {

	@Override
	public void init() throws ServletException {
		try {
			Connection con = Connector.connect();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String dob = req.getParameter("dob");
		String mobileNo = req.getParameter("mobileno");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String address = req.getParameter("address");
		String gender = req.getParameter("gender");

		UserDAOImpl uimpl = new UserDAOImpl();
		User u = new User(username,password,email,gender,address,mobileNo,dob);
		int i = uimpl.insertUserData(u);
		if(i==0) {
			resp.sendRedirect("UserRegistration.jsp");
		}
		else {
			resp.sendRedirect("UserLogin.jsp");
		}
	}

}
