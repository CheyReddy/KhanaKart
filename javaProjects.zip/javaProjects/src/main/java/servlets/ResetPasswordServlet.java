package servlets;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Connector;
import com.User;

import daoimpl.UserDAOImpl;

@WebServlet("/resetPassword")
public class ResetPasswordServlet extends HttpServlet {

	private HttpSession session;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		session = req.getSession();
		session.removeAttribute("error");
		session.setAttribute("error", "not");
		String password = req.getParameter("password");
		String confirmPassword = req.getParameter("confirmPassword");
		String email = req.getParameter("email");



		try {
			UserDAOImpl uimpl = new UserDAOImpl();
			User u = uimpl.getUserByEmail(email);
			String oldPwd = u.getPassword();

			Connection con = Connector.connect();
			if(password.compareTo(confirmPassword) == 0) {
				int x = uimpl.updateUser(password, email);
				if(password.equals(oldPwd)) {
					session.removeAttribute("error");
					session.setAttribute("error", "You have entered old password.!");
					resp.sendRedirect("ResetPassword.jsp");
				}
				else if(x != 0) {
					session.setAttribute("error", "not");
					resp.sendRedirect("UserLogin.jsp");
				}
				else {
					session.removeAttribute("error");
					session.setAttribute("error", "Try again.!");
					resp.sendRedirect("ResetPassword.jsp");
				}
			}
			else {
				session.removeAttribute("error");
				session.setAttribute("error", "Enter correct Password.!");
				resp.sendRedirect("ResetPassword.jsp");

			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}


	}
}
