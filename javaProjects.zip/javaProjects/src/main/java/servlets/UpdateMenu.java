package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Menu;

import daoimpl.MenuDAOImpl;

@WebServlet("/UpdateMenu")
public class UpdateMenu extends HttpServlet {
	private HttpSession session;
	private ArrayList<Menu> MenuList;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		session = req.getSession();
		int menuID = (int)Integer.parseInt(req.getParameter("menuid"));

		String itemstatus = req.getParameter("itemstatus");
		double price = Double.parseDouble(req.getParameter("price"));

		MenuDAOImpl mimpl = new MenuDAOImpl();
		int x = mimpl.updateMenuByRestaurantId(menuID, itemstatus, price);
		if(x!=0) {
			resp.sendRedirect("FetchMenu");
		}
		else {
			resp.sendRedirect("UpdateMenu.jsp");
		}
	}
}
