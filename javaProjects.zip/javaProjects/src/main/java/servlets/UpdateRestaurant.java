package servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Restaurant;

import daoimpl.RestaurantDAOImpl;


@WebServlet("/UpdateRestaurant")
public class UpdateRestaurant extends HttpServlet {
	private HttpSession session;
	private ArrayList<Restaurant> restaurantList;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		session = req.getSession();
		restaurantList = (ArrayList<Restaurant>) session.getAttribute("restaurantList");

		int restaurantsid = (Integer)session.getAttribute("restaurantsid");
		String isActive = req.getParameter("status");



		RestaurantDAOImpl rimpl = new RestaurantDAOImpl();

		int x = rimpl.updateRestById(restaurantsid, isActive);
		if(x!=0) {
			resp.sendRedirect("FetchRestaurant");
		}
		else {
			resp.sendRedirect("UpdateRestaurant.jsp");
		}
	}

}
