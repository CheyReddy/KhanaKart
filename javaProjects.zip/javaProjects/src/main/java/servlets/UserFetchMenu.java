package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Connector;
import com.Menu;


@WebServlet("/UserFetchMenu")
public class UserFetchMenu extends HttpServlet {
	String fetchAll = "select * from menu where restaurantid = ?";
	private PreparedStatement pstmt;
	private ResultSet res;
	private HttpSession session;
	private List<Menu> menuList = new ArrayList();

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			HttpSession session=req.getSession();
			Connection con = Connector.connect();
			pstmt = con.prepareStatement(fetchAll);	
			pstmt.setInt(1, (Integer)session.getAttribute("restaurantid"));
			res = pstmt.executeQuery();
			menuList.clear();
			while(res.next()) {
				menuList.add(new Menu(res.getInt("menuid"),res.getInt("restaurantid"), res.getString("itemName"), res.getString("itemDescription"), res.getDouble("price"),
						res.getString("isAvailable"), res.getString("imgPath")));
			}
			session = req.getSession();
			session.setAttribute("menuList", menuList);
			resp.sendRedirect("Menu.jsp");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
