package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Connector;
import com.User;

import daoimpl.UserDAOImpl;

@WebServlet("/UserValidation")
public class UserValidation extends HttpServlet {

	private HttpSession session;
	private ArrayList<User> userList = new ArrayList<>();


	@Override
	public void init() throws ServletException {
		try {
			Connection con = Connector.connect();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		session=req.getSession();
		session.removeAttribute("username");
		session.removeAttribute("error");
		String password = req.getParameter("password");
		String email = req.getParameter("email");

		UserDAOImpl uimpl = new UserDAOImpl();

			User u = uimpl.getUserByEmail(email);
			if(u!=null) {
				String dbPassword = u.getPassword();
				if(dbPassword.equals(password)) {
					userList.add(u);

					session.setAttribute("userList", userList);
					session.setAttribute("username", u.getUsername());

					resp.sendRedirect("UserHome.jsp");
				}
				else {
					session.setAttribute("error", "Invalid Password, Try again.!");
					resp.sendRedirect("UserLogin.jsp");
				}
			}
			else {
				session.setAttribute("error", "Invalid Email, Signup your account.!");
				resp.sendRedirect("UserLogin.jsp");
			}
		}


}
