package servlets;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Connector;
import com.User;

import daoimpl.UserDAOImpl;

@WebServlet("/validateEmail")
public class ValidateEmail extends HttpServlet {

	private HttpSession session;


	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			Connection con = Connector.connect();
			String email = req.getParameter("email");
			String dob = req.getParameter("dob");

			UserDAOImpl uimpl = new UserDAOImpl();
			User u = uimpl.userValidation(email, dob);

			session = req.getSession();
			session.setAttribute("email", email);


			if(email.equals(u.getEmail())) {
				if(dob.equals(u.getDob())) {
					resp.sendRedirect("ResetPassword.jsp");
				}
				else {
					session.setAttribute("error", "Invalid, Please enter valid DOB.");
					Cookie c1 = new Cookie("error","Invalid, Please enter valid DOB.");
					c1.setMaxAge(30);
					resp.addCookie(c1);
					resp.sendRedirect("emailValidation.jsp");
				}
			}
			else {
				session.setAttribute("error", "Invalid, Please enter valid Email & DOB.");
				resp.sendRedirect("emailValidation.jsp");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}


	}

}
